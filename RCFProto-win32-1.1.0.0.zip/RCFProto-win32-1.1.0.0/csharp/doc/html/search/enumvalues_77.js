var searchData=
[
  ['win32',['Win32',['../namespace_delta_v_soft_1_1_r_c_f_proto.html#a5e487eb2b0cf73e0fcf21caf2f5a87c6aa99913111481b4f0bcb70e08e3e99405',1,'DeltaVSoft::RCFProto']]],
  ['win32namedpipe',['Win32NamedPipe',['../namespace_delta_v_soft_1_1_r_c_f_proto.html#a0774d401b79cd658ca48b449a360ed1fafe87c3fe11e444d783aa733ff459c535',1,'DeltaVSoft::RCFProto']]]
];
