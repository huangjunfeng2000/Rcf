var searchData=
[
  ['httpendpoint_2ecs',['HttpEndpoint.cs',['../_http_endpoint_8cs.html',1,'']]],
  ['httpsendpoint_2ecs',['HttpsEndpoint.cs',['../_https_endpoint_8cs.html',1,'']]]
];
