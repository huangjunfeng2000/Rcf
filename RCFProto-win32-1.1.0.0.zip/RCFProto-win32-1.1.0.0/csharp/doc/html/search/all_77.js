var searchData=
[
  ['win32',['Win32',['../namespace_delta_v_soft_1_1_r_c_f_proto.html#a5e487eb2b0cf73e0fcf21caf2f5a87c6aa99913111481b4f0bcb70e08e3e99405',1,'DeltaVSoft::RCFProto']]],
  ['win32certificate',['Win32Certificate',['../class_delta_v_soft_1_1_r_c_f_proto_1_1_win32_certificate.html',1,'DeltaVSoft::RCFProto']]],
  ['win32certificate_2ecs',['Win32Certificate.cs',['../_win32_certificate_8cs.html',1,'']]],
  ['win32certificatelocation',['Win32CertificateLocation',['../namespace_delta_v_soft_1_1_r_c_f_proto.html#a7c8a1f4e48b20dcddd5aaf6e956d2bb6',1,'DeltaVSoft::RCFProto']]],
  ['win32certificatelocation_2ecs',['Win32CertificateLocation.cs',['../_win32_certificate_location_8cs.html',1,'']]],
  ['win32certificatestore',['Win32CertificateStore',['../namespace_delta_v_soft_1_1_r_c_f_proto.html#a8b8e5f8eaa66f6ef0887aea921dfab7c',1,'DeltaVSoft::RCFProto']]],
  ['win32certificatestore_2ecs',['Win32CertificateStore.cs',['../_win32_certificate_store_8cs.html',1,'']]],
  ['win32namedpipe',['Win32NamedPipe',['../namespace_delta_v_soft_1_1_r_c_f_proto.html#a0774d401b79cd658ca48b449a360ed1fafe87c3fe11e444d783aa733ff459c535',1,'DeltaVSoft::RCFProto']]],
  ['win32namedpipeendpoint',['Win32NamedPipeEndpoint',['../class_delta_v_soft_1_1_r_c_f_proto_1_1_win32_named_pipe_endpoint.html#aa3f7014f38bd829a0e7e650205dd76a8',1,'DeltaVSoft::RCFProto::Win32NamedPipeEndpoint']]],
  ['win32namedpipeendpoint',['Win32NamedPipeEndpoint',['../class_delta_v_soft_1_1_r_c_f_proto_1_1_win32_named_pipe_endpoint.html',1,'DeltaVSoft::RCFProto']]],
  ['win32namedpipeendpoint_2ecs',['Win32NamedPipeEndpoint.cs',['../_win32_named_pipe_endpoint_8cs.html',1,'']]]
];
