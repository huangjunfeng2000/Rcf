var searchData=
[
  ['http',['Http',['../namespace_delta_v_soft_1_1_r_c_f_proto.html#a0774d401b79cd658ca48b449a360ed1fa9d4d43de68f0b3555d5a5ef5dc05bb95',1,'DeltaVSoft::RCFProto']]],
  ['https',['Https',['../namespace_delta_v_soft_1_1_r_c_f_proto.html#a0774d401b79cd658ca48b449a360ed1fa2badb7fa3e862298a650909d45c5066b',1,'DeltaVSoft::RCFProto']]]
];
