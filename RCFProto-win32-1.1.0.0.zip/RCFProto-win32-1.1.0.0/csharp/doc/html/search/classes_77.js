var searchData=
[
  ['win32certificate',['Win32Certificate',['../class_delta_v_soft_1_1_r_c_f_proto_1_1_win32_certificate.html',1,'DeltaVSoft::RCFProto']]],
  ['win32namedpipeendpoint',['Win32NamedPipeEndpoint',['../class_delta_v_soft_1_1_r_c_f_proto_1_1_win32_named_pipe_endpoint.html',1,'DeltaVSoft::RCFProto']]]
];
