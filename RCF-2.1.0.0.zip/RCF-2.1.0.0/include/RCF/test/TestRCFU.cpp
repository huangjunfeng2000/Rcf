
#if !defined(UNICODE)  || !defined(_UNICODE)
#error Unicode build is not enabled.
#endif

#include "TestRCF.cpp"
